var express=require("express");
var mongoose=require("mongoose");
var article=require("./models/article");
var routes=require("./routes/articles")
var app=express()
const methodoverride=require("method-override")
mongoose.connect("mongodb://localhost/myblog",{useNewUrlParser:true,useCreateIndex:true,useUnifiedTopology:true});

app.set('view engine', 'ejs')
app.use(methodoverride('_method'))
app.use(express.urlencoded({ extended: false }))
//app.use(methodOverride('_method'))

app.get('/',async (req,res)=>{
    const myarticle=await article.find()
    res.render('index',{article:myarticle});
    
})

app.use('/articles',routes);
app.listen("3000")
