var mongoose=require("mongoose");
const createDOMPurify = require('dompurify');
const { JSDOM } = require('jsdom');

//const window = new JSDOM('').window;
const DOMPurify = createDOMPurify(new JSDOM().window);
const marked=require('marked')
var articledb=new mongoose.Schema({
    title:{
        type:String,
        required:true,
    },
    description:{
        type:String,
        required:true,
    },
    markdown:{
        type:String,
        
    },
    creationdate:
    {
        required:true,
        type:Date,
        default:Date.now()
    },
    sanitizedHtml:
    {
        required:true,
        type:String,
    }
})
articledb.pre('validate',function(next)
{
    if(this.markdown)
    {
        this.sanitizedHtml=DOMPurify.sanitize(marked(this.markdown))
    }
    next()
})



module.exports=mongoose.model('article',articledb);