var express = require("express");
var mongoose = require("mongoose");
var Article = require("../models/article");
//var routes=require("./routes/articles")
var router = express.Router()
router.get('/new', (req, res) => {
    var myarticle =new Article();
    try {
        res.render('new', { article: myarticle })
        console.log('here 1')
       // console.log(err)
    }
    catch
    {
        res.redirect('/');
        console.log('here 2')
    }
        
})

router.get('/edit/:id', async (req, res) => {
    var myarticle = await Article.findById(req.params.id);
    try {
        res.render('edit', { article: myarticle })
    }
    catch
    {
        res.redirect('/');
    }

})

router.get('/:id', async (req, res) => {
    var myarticle = await Article.findById(req.params.id);
    try {
        res.render('readmore', { article: myarticle })
    }
    catch
    {
        res.redirect('/');
    }

})
// router.post('/:id', async (req, res) => {
//     var myarticle = await Article.findById(req.params.id);
//     try {
//         res.render('readmore', { article: myarticle })
//     }
//     catch
//     {
//         res.redirect('/');
//     }

// })


router.post('/:id', async (req, res) => {
    var myarticle2 = new Article({
        title: req.body.title,
        description: req.body.description,
        markdown: req.body.markdown,
        creationdate: req.body.creationdate,
        //console.log("post    "+myarticle2)

    })
console.log(myarticle2)

    const a1 = await myarticle2.save()
        console.log("here3")
        res.render('readmore', { article: myarticle2 });
        //console.log(err)
})



router.put('/:id', async (req, res) => {
    var myarticle2=await Article.findById(req.params.id)
    
    myarticle2.title= req.body.title;
    myarticle2.description= req.body.description;
    myarticle2.markdown= req.body.markdown;
    //myarticle2.creationdate= req.body.creationdatemyarticle;
    // try {
    //     const a1 = await myarticle2.save()
    //     res.render('readmore', { article: myarticle2 });
        
    // }
    // catch {
    //     res.redirect('/')
    // }
    console.log(myarticle2)
         const a1 =  myarticle2.save()
        res.render('readmore', { article: myarticle2 });
        
})

router.delete('/:id',async (req,res)=>{
    try{
        await Article.findByIdAndDelete(req.params.id);
        res.redirect('/')
    }
    catch
    {
        res.redirect('/')
    }
  

})

module.exports=router;